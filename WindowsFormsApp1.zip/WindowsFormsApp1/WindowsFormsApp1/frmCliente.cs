﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmCliente : Form
    {
        public frmCliente()
        {
            InitializeComponent();
        }

        private void frmCliente_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'cadastroDataSet.tbcliente'. Você pode movê-la ou removê-la conforme necessário.
            this.tbclienteTableAdapter.Fill(this.cadastroDataSet.tbcliente);

        }

        private void tbclienteBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tbclienteBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.cadastroDataSet);

        }

        private void nm_clienteLabel_Click(object sender, EventArgs e)
        {

        }

        private void ds_enderecoLabel_Click(object sender, EventArgs e)
        {

        }

        private void nm_bairroLabel_Click(object sender, EventArgs e)
        {

        }

        private void cd_clienteLabel_Click(object sender, EventArgs e)
        {

        }

        private void nm_cidadeLabel_Click(object sender, EventArgs e)
        {

        }

        private void sg_estadoLabel_Click(object sender, EventArgs e)
        {

        }

        private void cd_cpfLabel_Click(object sender, EventArgs e)
        {

        }

        private void cd_cepLabel_Click(object sender, EventArgs e)
        {

        }

        private void cd_rgLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
