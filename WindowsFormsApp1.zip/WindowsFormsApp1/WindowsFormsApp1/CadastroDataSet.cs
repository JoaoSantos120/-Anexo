﻿namespace WindowsFormsApp1
{
}

namespace WindowsFormsApp1 {
    
    
    public partial class CadastroDataSet {
    }
}
namespace WindowsFormsApp1 {
    
    
    public partial class CadastroDataSet {
    }
}
