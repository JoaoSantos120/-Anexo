<ul class="list-unstyled components">
                    <p>Dashboard</p>
                    <li class="active">
                        <a href="#sub1" data-toggle="collapse" aria-expanded="false">Meu Perfil</a>
                        <ul class="collapse list-unstyled" id="sub1">
                            <li><a href="#">Dados de Contato</a></li>
                            <li><a href="#">Atualizar foto</a></li>
                            <li><a href="#">Email e Senha</a></li>
                            <li><a href="#">Excluir conta</a></li>
                        </ul>
                    </li>
                    <!--<li>                        -->
                    <!--    <a href="#sub2" data-toggle="collapse" aria-expanded="false">Gerenciar</a>-->
                    <!--    <ul class="collapse list-unstyled" id="sub2">-->
                    <!--        <li><a href="#">currículos</a></li>-->
                    <!--        <li><a href="#">escolaridade</a></li>-->
                    <!--        <li><a href="#">Branco</a></li>-->
                    <!--    </ul>-->
                    <!--</li>-->
                    <li>
                        <a href="#">Meus Currículos</a>
                    </li>
                    <!--<li>-->
                    <!--    <a href="#">Novo currículo</a>-->
                    <!--</li>-->
                </ul>